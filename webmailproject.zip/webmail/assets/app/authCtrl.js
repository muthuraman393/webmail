var navCtrl = app.controller('navCtrl', function($scope, $rootScope, $routeParams, $location, $filter) {
    $scope.homeitems = [{
        nameid: 'ford_1',
        src: 'img/puzzle/casa3x2/fiesta/Ford_Original.png',
        car: 'fiesta'
    }, {
        nameid: 'ford_2',
        src: 'img/puzzle/casa3x2/focus/Ford_Original.png',
        car: 'focus'
    }, {
        nameid: 'ford_3',
        src: 'img/puzzle/casa3x2/fusion/Ford_Original.png',
        car: 'fusion'
    }, {
        nameid: 'ford_4',
        src: 'img/puzzle/casa3x2/mustang/Ford_Original.png',
        car: 'mustang'
    }];

    $scope.query = {}
    $scope.queryBy = '$'

    $scope.list2 = [{
            'tickboxid': 1,
            'tdstarcls': true,
            'subject': 'Maria Alphonse',
            'text': 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
            'attach': false,
            'time': '3 minutes ago',
            'labelname': 'Work',
            'labelcolor': 'btn-redcolor',
            'avatar': true
        }, {
            'tickboxid': 2,
            'tdstarcls': false,
            'subject': 'Madison christopher',
            'text': 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
            'attach': true,
            'time': '3 minutes ago',
            'labelname': 'Family',
            'labelcolor': 'btn-orangecolor',
            'avatar': false
        }, {
            'tickboxid': 3,
            'tdstarcls': true,
            'subject': 'Adam Alphonse',
            'text': 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
            'attach': true,
            'time': '3 minutes ago',
            'labelname': 'Work',
            'labelcolor': 'btn-redcolor',
            'avatar': true
        }, {
            'tickboxid': 4,
            'tdstarcls': false,
            'subject': 'Nydison christopher',
            'text': 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
            'attach': false,
            'time': '3 minutes ago',
            'labelname': 'FAmily',
            'labelcolor': 'btn-orangecolor',
            'avatar': false
        }, {
            'tickboxid': 5,
            'tdstarcls': true,
            'subject': 'Mathew Aristo',
            'text': 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
            'attach': true,
            'time': '3 minutes ago',
            'labelname': 'Work',
            'labelcolor': 'btn-redcolor',
            'avatar': true
        }, {
            'tickboxid': 6,
            'tdstarcls': true,
            'subject': 'JoE Alphonse',
            'text': 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
            'attach': false,
            'time': '3 minutes ago',
            'labelname': 'Family',
            'labelcolor': 'btn-orangecolor',
            'avatar': false
        }, {
            'tickboxid': 7,
            'tdstarcls': false,
            'subject': 'Steve John',
            'text': 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
            'attach': true,
            'time': '3 minutes ago',
            'labelname': 'Work',
            'labelcolor': 'btn-redcolor',
            'avatar': true
        }, {
            'tickboxid': 8,
            'tdstarcls': true,
            'subject': 'Emily Mahi',
            'text': 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
            'attach': false,
            'time': '3 minutes ago',
            'labelname': 'Work',
            'labelcolor': 'btn-redcolor',
            'avatar': true
        }, {
            'tickboxid': 9,
            'tdstarcls': false,
            'subject': 'Danny Alphonse',
            'text': 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
            'attach': true,
            'time': '3 minutes ago',
            'labelname': 'Work',
            'labelcolor': 'btn-redcolor',
            'avatar': true
        }, {
            'tickboxid': 10,
            'tdstarcls': true,
            'subject': 'Alphonse Rand',
            'text': 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
            'attach': true,
            'time': '3 minutes ago',
            'labelname': 'Family',
            'labelcolor': 'btn-orangecolor',
            'avatar': false
        }, {
            'tickboxid': 11,
            'tdstarcls': true,
            'subject': 'Baskar Ram',
            'text': 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
            'attach': false,
            'time': '3 minutes ago',
            'labelname': 'Work',
            'labelcolor': 'btn-redcolor',
            'avatar': true
        }, {
            'tickboxid': 12,
            'tdstarcls': true,
            'subject': 'Jeya Alphonse',
            'text': 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
            'attach': true,
            'time': '3 minutes ago',
            'labelname': 'Work',
            'labelcolor': 'btn-redcolor',
            'avatar': true
        }, {
            'tickboxid': 13,
            'tdstarcls': false,
            'subject': 'Emily Kareena',
            'text': 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
            'attach': false,
            'time': '3 minutes ago',
            'labelname': 'Work',
            'labelcolor': 'btn-redcolor',
            'avatar': false
        }, {
            'tickboxid': 14,
            'tdstarcls': true,
            'subject': 'Sharuhk Khan',
            'text': 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
            'attach': true,
            'time': '3 minutes ago',
            'labelname': 'Work',
            'labelcolor': 'btn-redcolor',
            'avatar': true
        }, {
            'tickboxid': 15,
            'tdstarcls': false,
            'subject': 'Daniel Alphonse',
            'text': 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
            'attach': false,
            'time': '3 minutes ago',
            'labelname': 'Family',
            'labelcolor': 'btn-orangecolor',
            'avatar': false
        }, {
            'tickboxid': 16,
            'tdstarcls': false,
            'subject': 'Balaji MSSS',
            'text': 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
            'attach': true,
            'time': '3 minutes ago',
            'labelname': 'Work',
            'labelcolor': 'btn-redcolor',
            'avatar': true
        }, {
            'tickboxid': 17,
            'tdstarcls': true,
            'subject': 'Raghu Jane',
            'text': 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
            'attach': false,
            'time': '3 minutes ago',
            'labelname': 'Work',
            'labelcolor': 'btn-redcolor',
            'avatar': true
        }

    ];
    angular.forEach($scope.list2, function(item) {
        item.Selected = false;
    });

    $scope.visiblecompose = true; //to true
    $scope.visiblepencil = false;
    $scope.visiblecross = true;
    $scope.visibleinnermail = true;
    $scope.visibleinnermailopensend = true;
    $scope.tickboxunselected = false;
    $scope.toreplyclass = false;



    $scope.composeopen = function() {
        $scope.visiblecompose = true; //to false

        if ($scope.visiblecross == false && $scope.visiblepencil == true) {
            $scope.visiblepencil = false;
            $scope.visiblecross = true;

        } else {
            $scope.visiblecross = false;
            $scope.visiblepencil = true;
            $scope.visiblecompose = false;

        }

    };
    $scope.composeclose = function() {
        //$scope.visiblecompose = true;
    };

    $scope.innermailopen = function() {
        $scope.visibleinnermail = false;

    };
    $scope.innermailclose = function() {
        $scope.visibleinnermail = true;

    };
    $scope.stateChanged = function(tickid, qId) {
        if ($scope.list2[tickid - 1].Selected == false) {
            //alert('test'+$scope.list2[tickid-1].Selected+'_innermail'+$scope.visibleinnermail);
            $scope.visibleinnermailopensend = true;
            $scope.toreplyclass = false;
            var falsecount = 0;

            angular.forEach($scope.list2, function(item) { /*to check uncheck master*/
                if (item.Selected == true) {
                    $scope.tickboxunselected = true;
                    return false;
                } else {
                    falsecount = falsecount + 1;

                    if (falsecount == $scope.list2.length) {
                        $scope.tickboxunselected = false;
                        $scope.selectedAll = false;
                    }
                }
            });

        }
        if ($scope.list2[tickid - 1].Selected == true) {
            $scope.visibleinnermailopensend = false;
            $scope.toreplyclass = true;

            angular.forEach($scope.list2, function(item) { /*to check uncheck master*/
                if (item.Selected == true) {
                    $scope.tickboxunselected = true;
                    return false;
                } else {
                    falsecount = falsecount + 1;

                    if (falsecount == $scope.list2.length) {
                        $scope.tickboxunselected = false;
                        $scope.selectedAll = false;
                    }
                }
            });

        }
    };




    /* 		$scope.innermailopensend = function() {
            $scope.visibleinnermailopensend = $scope.visibleinnermailopensend?false:true;
            }; */

    $scope.checkAll = function() {
        $scope.tickboxunselected = false;
        if ($scope.selectedAll) {
            //alert('if'+$scope.selectedAll);
            $scope.selectedAll = false;
        } else {
            //alert('else'+$scope.selectedAll);
            $scope.selectedAll = true;
        }
        angular.forEach($scope.list2, function(item) {
            item.Selected = $scope.selectedAll;
        });

    };


});